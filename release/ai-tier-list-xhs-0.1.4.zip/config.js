window.AITier.config={"applicationId":"ai-tier-list","platform":"xhs","version":"0.1.4","demo":false};
