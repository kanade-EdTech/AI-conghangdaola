window.AITier.config={"applicationId":"ai-tier-list","platform":"toy","version":"0.1.4","demo":false};
